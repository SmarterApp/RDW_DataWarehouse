"""
Define configuration parameters for general enrollments.

:author: nestep
:date: February 26, 2014
"""

NUMBER_OF_SECTIONS = 1  # TODO: Make use of this
TEACHERS_PER_SECTION = 1