"""Model the core of a class.

:author: nestep
:date: February 24, 2014
"""

from mongoengine import Document, ReferenceField, StringField

from data_generation import run_id as global_run_id
from data_generation.model.school import School


class Class(Document):
    """The core of a class.
    """
    run_id = StringField(required=True, default=global_run_id)
    guid = StringField(required=True, primary_key=True)
    school = ReferenceField(School, required=True)
    name = StringField(required=True)
    subject = StringField(required=True)

    meta = {'allow_inheritance': True}