"""Model the generals of a student.

:author: nestep
:date: February 22, 2014
"""

from mongoengine import BooleanField, DateTimeField, Document, IntField, ReferenceField, StringField

from data_generation import run_id as global_run_id
from data_generation.model.school import School


class Student(Document):
    """The core student class.
    """
    run_id = StringField(required=True, default=global_run_id)
    guid = StringField(required=True, primary_key=True)
    school = ReferenceField(School, required=True)
    grade = IntField(required=True)
    gender = StringField(required=True)
    first_name = StringField(required=True)
    middle_name = StringField(required=False)
    last_name = StringField(required=True)
    dob = DateTimeField(required=True)
    email = StringField(required=False)
    address_line_1 = StringField(required=False)
    address_line_2 = StringField(required=False)
    address_city = StringField(required=False)
    address_zip = IntField(required=False)
    eth_white = BooleanField(required=True, default=False)
    eth_black = BooleanField(required=True, default=False)
    eth_hispanic = BooleanField(required=True, default=False)
    eth_asian = BooleanField(required=True, default=False)
    eth_pacific = BooleanField(required=True, default=False)
    eth_amer_ind = BooleanField(required=True, default=False)
    eth_multi = BooleanField(required=True, default=False)
    eth_none = BooleanField(required=True, default=False)
    prg_iep = BooleanField(required=False)
    prg_sec504 = BooleanField(required=False)
    prg_lep = BooleanField(required=False)
    prg_econ_disad = BooleanField(required=False)
    held_back = BooleanField(required=True, default=False)

    meta = {'allow_inheritance': True}

    @property
    def name(self):
        """The full name of student.
        """
        if self.middle_name is not None:
            return self.first_name + ' ' + self.middle_name + ' ' + self.last_name
        else:
            return self.first_name + ' ' + self.last_name

    def get_object_set(self):
        """Get the set of objects that this exposes to a CSV or JSON writer.

        :returns: Dictionary of root objects
        """
        return {'state': self.school.district.state,
                'district': self.school.district,
                'school': self.school,
                'student': self}