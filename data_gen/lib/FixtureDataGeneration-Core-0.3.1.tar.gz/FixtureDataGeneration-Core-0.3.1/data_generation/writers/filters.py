"""Create output filters for data values.

:author: nestep
:date: March 6, 2014
"""


def filter_date_Y_m_d(val):
    """Filter a Date/Time value as %Y-%m-%d.

    :param val: The value to filter
    :returns: %Y-%m-%d format of Date/Time
    """
    return val.strftime('%Y-%m-%d') if val is not None else None


def filter_date_Ymd(val):
    """Filter a Date/Time value as %Y%m%d.

    :param val: The value to filter
    :returns: %Y%m%d format of Date/Time
    """
    return val.strftime('%Y%m%d') if val is not None else None


def filter_date_Y(val):
    """Filter a Date/Time value as %Y.

    :param val: The value to filter
    :returns: %Y format of Date/Time
    """
    return val.strftime('%Y') if val is not None else None


def filter_date_m(val):
    """Filter a Date/Time value as %m.

    :param val: The value to filter
    :returns: %m format of Date/Time
    """
    return val.strftime('%m') if val is not None else None


def filter_date_d(val):
    """Filter a Date/Time value as %d.

    :param val: The value to filter
    :returns: %d format of Date/Time
    """
    return val.strftime('%d') if val is not None else None


FILTERS = {
    'date_Y_m_d': filter_date_Y_m_d,
    'date_Ymd': filter_date_Ymd,
    'date_Y': filter_date_Y,
    'date_m': filter_date_m,
    'date_d': filter_date_d
}