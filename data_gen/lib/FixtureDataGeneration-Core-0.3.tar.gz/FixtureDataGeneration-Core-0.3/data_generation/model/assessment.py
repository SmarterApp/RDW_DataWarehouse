"""Model the core of an assessment.

:author: nestep
:date: February 24, 2014
"""

from mongoengine import Document, StringField

from data_generation import run_id as global_run_id


class Assessment(Document):
    """The core assessment class.
    """
    run_id = StringField(required=True, default=global_run_id)
    guid = StringField(required=True, primary_key=True)

    meta = {'allow_inheritance': True}

    def get_object_set(self):
        """Get the set of objects that this exposes to a CSV or JSON writer.

        Root objects made available:
          - assessment

        :returns: Dictionary of root objects
        """
        return {'assessment': self}