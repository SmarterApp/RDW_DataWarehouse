"""Model the core of a school.

:author: nestep
:date: February 21, 2014
"""

from mongoengine import DictField, Document, ReferenceField, StringField

from data_generation import run_id as global_run_id
from data_generation.model.district import District


class School(Document):
    """The core of a school.
    """
    run_id = StringField(required=True, default=global_run_id)
    guid = StringField(required=True, primary_key=True)
    name = StringField(required=True)
    district = ReferenceField(District, required=True)
    type_str = StringField(required=True)
    config = DictField(required=True)
    demo_config = DictField(required=True)

    meta = {'allow_inheritance': True}

    @property
    def grades(self):
        """The grades in the school, ordered low to high.
        """
        return sorted(self.config['grades'])

    @property
    def student_count_min(self):
        """The minimum number of students to have in a grade for this school.
        """
        return self.config['students']['min']

    @property
    def student_count_max(self):
        """The maximum number of students to have in a grade for this school.
        """
        return self.config['students']['max']

    @property
    def student_count_avg(self):
        """The average number of students to have in a grade for this school.
        """
        if 'avg' not in self.config['students']:
            smin, smax = self.config['students']['min'], self.config['students']['max']
            self.config['students']['avg'] = ((smax - smin) // 2) + smin
            self.save()
        return self.config['students']['avg']