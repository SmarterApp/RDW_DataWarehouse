"""Model the core of a section.

:author: nestep
:date: February 24, 2014
"""

from mongoengine import BooleanField, DateTimeField, Document, IntField, ListField, ReferenceField, StringField

from data_generation import run_id as global_run_id
from data_generation.model.clss import Class
from data_generation.model.staff import Staff


class Section(Document):
    """The core of a section.
    """
    run_id = StringField(required=True, default=global_run_id)
    guid = StringField(required=True, primary_key=True)
    clss = ReferenceField(Class, required=True)
    teachers = ListField(ReferenceField(Staff, required=False))
    name = StringField(required=True)
    grade = IntField(required=True)
    from_date = DateTimeField(required=True)
    to_date = DateTimeField(required=False)
    most_recent = BooleanField(required=True)

    meta = {'allow_inheritance': True}

    def get_object_set(self):
        """Get the set of objects that this exposes to a CSV or JSON writer.

        Root objects made available:
          - state
          - district
          - school
          - class
          - section

        :returns: Dictionary of root objects
        """
        return {'state': self.clss.school.district.state,
                'district': self.clss.school.district,
                'school': self.clss.school,
                'class': self.clss,
                'section': self}