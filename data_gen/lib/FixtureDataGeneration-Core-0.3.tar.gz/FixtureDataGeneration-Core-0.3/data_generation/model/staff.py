"""Model the core of different staff members.

:author: nestep
:date: February 22, 2014
"""

from mongoengine import Document, ReferenceField, StringField

from data_generation import run_id as global_run_id
from data_generation.model.district import District
from data_generation.model.school import School


class Staff(Document):
    """The core staff class.
    """
    run_id = StringField(required=True, default=global_run_id)
    guid = StringField(required=True, primary_key=True)
    gender = StringField(required=True)
    first_name = StringField(required=True)
    middle_name = StringField(required=False)
    last_name = StringField(required=True)

    meta = {'allow_inheritance': True}

    @property
    def name(self):
        """The full name of the staff member.
        """
        if self.middle_name is not None:
            return self.first_name + ' ' + self.middle_name + ' ' + self.last_name
        else:
            return self.first_name + ' ' + self.last_name


class DistrictStaff(Staff):
    """Specifics for a district-level staff member.
    """
    district = ReferenceField(District, required=True)


class TeachingStaff(Staff):
    """Specifics for a teaching staff member.
    """
    school = ReferenceField(School, required=True)