"""Model the core of a state.

:author: nestep
:date: February 21, 2014
"""

from mongoengine import DictField, Document, StringField

from data_generation import run_id as global_run_id


class State(Document):
    """The core of a state.
    """
    run_id = StringField(required=True, default=global_run_id)
    guid = StringField(required=True, primary_key=True)
    name = StringField(required=True)
    code = StringField(required=True)
    type_str = StringField(required=True)
    config = DictField(required=True)
    demo_config = DictField(required=True)

    meta = {'allow_inheritance': True}
