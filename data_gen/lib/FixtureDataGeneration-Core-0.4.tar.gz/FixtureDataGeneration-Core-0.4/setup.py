"""Setup script that can be used to build the project into a distributable package.

Note: This will not package tasks or unit tests into the distributable, but does include the data files for name
generation. Also, if projects for specific teams are included in the future, they will not be built into the
distributable either as this script is written right now.

Run like this: python setup.py sdist --formats=gztar

:author: nestep
:date: March 16, 2014
"""

import setuptools
import os

here = os.path.abspath(os.path.dirname(__file__))
README = open(os.path.join(here, 'README.md')).read()

requires = ['sphinx',
            'psycopg2']

tests_require = requires + ['nose',
                            'pep8',
                            'coverage']

setuptools.setup(name='FixtureDataGeneration-Core',
                 version='0.4',
                 description='Fixture data generator for education projects',
                 author='TRON - Amplify Insight',
                 author_email='insight_tron@amplify.com',
                 maintainer='TRON - Amplify Insight',
                 maintainer_email='insight_tron@amplify.com',
                 license='proprietary',
                 url='https://github.wgenhq.net/Data-Generation/data-generation',
                 classifiers=['Programming Language :: Python', 'Programming Language :: Python :: 3.3',
                              'Operating System :: OS Independent', 'Intended Audience :: Developers',
                              'Topic :: Education', 'Topic :: Software Development :: Quality Assurance',
                              'Topic :: Software Development :: Testing', 'Topic :: Utilities'],
                 keywords='fixture data generation education',
                 packages=['data_generation', 'data_generation.config', 'data_generation.datafiles',
                           'data_generation.generators', 'data_generation.model', 'data_generation.util',
                           'data_generation.writers'],
                 package_data={'data_generation.datafiles': ['*']},
                 include_package_data=True,
                 zip_safe=False,
                 test_suite='nose.collector',
                 install_requires=requires,
                 tests_require=tests_require,
                 entry_points='')
